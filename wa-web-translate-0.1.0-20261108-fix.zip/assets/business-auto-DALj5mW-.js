const s="waTranslate:business:auto-lease",a="waTranslate:business:auto-status",S="waTranslate:business:arrival-order",t=5e3,_=3e4;export{t as A,s as B,a,S as b,_ as c};
//# sourceMappingURL=business-auto-DALj5mW-.js.map
